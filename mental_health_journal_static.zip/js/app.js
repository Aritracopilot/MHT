// Main Application JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap components
    initializeBootstrapComponents();
    
    // Initialize navigation
    initializeNavigation();
    
    // Initialize week selector
    initializeWeekSelector();
    
    // Initialize mood sliders
    initializeMoodSliders();
    
    // Initialize data export/import
    initializeDataManagement();
    
    // Load initial data
    loadInitialData();
});

// Bootstrap Components Initialization
function initializeBootstrapComponents() {
    // Initialize all tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize all popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Initialize toast
    const toastElList = [].slice.call(document.querySelectorAll('.toast'));
    toastElList.map(function (toastEl) {
        return new bootstrap.Toast(toastEl, { autohide: true, delay: 3000 });
    });
}

// Navigation Initialization
function initializeNavigation() {
    // Sidebar toggle for mobile
    const sidebarToggle = document.getElementById('sidebarToggle');
    const closeSidebar = document.getElementById('closeSidebar');
    const sidebar = document.getElementById('sidebar');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    if (closeSidebar) {
        closeSidebar.addEventListener('click', function() {
            sidebar.classList.remove('active');
        });
    }
    
    // Page navigation
    const navLinks = document.querySelectorAll('[data-page]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            navigateToPage(targetPage);
            
            // Close sidebar on mobile after navigation
            if (window.innerWidth < 768) {
                sidebar.classList.remove('active');
            }
        });
    });
    
    // Set active nav item based on current page
    function setActiveNavItem(pageId) {
        const navItems = document.querySelectorAll('.sidebar ul li');
        navItems.forEach(item => {
            item.classList.remove('active');
            const link = item.querySelector('a');
            if (link && link.getAttribute('data-page') === pageId) {
                item.classList.add('active');
            }
        });
    }
    
    // Navigate to page function
    function navigateToPage(pageId) {
        const pages = document.querySelectorAll('.page');
        pages.forEach(page => {
            page.classList.remove('active');
        });
        
        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
            setActiveNavItem(pageId);
            
            // Load page-specific data if needed
            if (pageId === 'journal') {
                loadJournalEntries();
            } else if (pageId === 'mood-tracker') {
                loadMoodAnalytics();
            } else if (pageId === 'tags') {
                loadTagsManagement();
            } else if (pageId === 'dashboard') {
                loadDashboardData();
            }
        }
    }
    
    // New Entry button
    const newEntryBtn = document.getElementById('newEntryBtn');
    if (newEntryBtn) {
        newEntryBtn.addEventListener('click', function() {
            openJournalEntryModal();
        });
    }
    
    // Create First Entry button
    const createFirstEntry = document.getElementById('createFirstEntry');
    if (createFirstEntry) {
        createFirstEntry.addEventListener('click', function() {
            openJournalEntryModal();
        });
    }
    
    // Add data management button to header
    const headerActions = document.querySelector('.header-actions');
    if (headerActions) {
        const dataBtn = document.createElement('button');
        dataBtn.className = 'btn btn-outline-secondary ms-2';
        dataBtn.innerHTML = '<i class="bi bi-cloud-arrow-up-down"></i>';
        dataBtn.setAttribute('title', 'Export/Import Data');
        dataBtn.addEventListener('click', function() {
            const dataModal = new bootstrap.Modal(document.getElementById('dataModal'));
            dataModal.show();
        });
        headerActions.appendChild(dataBtn);
    }
}

// Week Selector Initialization
function initializeWeekSelector() {
    const prevWeekBtn = document.getElementById('prevWeek');
    const nextWeekBtn = document.getElementById('nextWeek');
    const currentWeekDisplay = document.getElementById('currentWeekDisplay');
    
    // Get current week and year from settings or calculate
    const settings = SettingsStorage.getSettings();
    let currentWeek = settings.currentWeek || getCurrentWeekNumber();
    let currentYear = settings.currentYear || new Date().getFullYear();
    
    // Update week display
    function updateWeekDisplay() {
        currentWeekDisplay.textContent = `Week ${currentWeek}, ${currentYear}`;
        
        // Save current week and year to settings
        SettingsStorage.updateSettings({
            currentWeek: currentWeek,
            currentYear: currentYear
        });
        
        // Update data based on selected week
        loadDataForWeek(currentWeek, currentYear);
    }
    
    // Initialize with current week
    updateWeekDisplay();
    
    // Previous week button
    if (prevWeekBtn) {
        prevWeekBtn.addEventListener('click', function() {
            currentWeek--;
            if (currentWeek < 1) {
                currentWeek = 52;
                currentYear--;
            }
            updateWeekDisplay();
        });
    }
    
    // Next week button
    if (nextWeekBtn) {
        nextWeekBtn.addEventListener('click', function() {
            currentWeek++;
            if (currentWeek > 52) {
                currentWeek = 1;
                currentYear++;
            }
            updateWeekDisplay();
        });
    }
    
    // Year selector for mood tracker
    const prevYearBtn = document.getElementById('prevYear');
    const nextYearBtn = document.getElementById('nextYear');
    const currentYearDisplay = document.getElementById('currentYearDisplay');
    
    if (currentYearDisplay) {
        currentYearDisplay.textContent = currentYear;
    }
    
    if (prevYearBtn) {
        prevYearBtn.addEventListener('click', function() {
            currentYear--;
            currentYearDisplay.textContent = currentYear;
            loadMoodAnalytics(currentYear);
        });
    }
    
    if (nextYearBtn) {
        nextYearBtn.addEventListener('click', function() {
            currentYear++;
            currentYearDisplay.textContent = currentYear;
            loadMoodAnalytics(currentYear);
        });
    }
}

// Mood Sliders Initialization
function initializeMoodSliders() {
    // Quick mood check-in sliders
    initializeSlider('moodScore', '.mood-value');
    initializeSlider('energyLevel', '.energy-value');
    
    // Journal entry mood sliders
    initializeSlider('journalMoodScore', '.mood-value');
    initializeSlider('journalEnergyLevel', '.energy-value');
    
    function initializeSlider(sliderId, valueSelector) {
        const slider = document.getElementById(sliderId);
        if (!slider) return;
        
        const valueDisplay = slider.closest('.mood-slider-container').querySelector(valueSelector);
        
        // Update value display on input
        slider.addEventListener('input', function() {
            valueDisplay.textContent = `${this.value}/10`;
        });
    }
    
    // Quick mood form submission
    const quickMoodForm = document.getElementById('quickMoodForm');
    if (quickMoodForm) {
        quickMoodForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const moodScore = document.getElementById('moodScore').value;
            const energyLevel = document.getElementById('energyLevel').value;
            const moodNotes = document.getElementById('moodNotes').value;
            
            // Create a new journal entry with mood data
            createQuickMoodEntry(moodScore, energyLevel, moodNotes);
        });
    }
}

// Initialize Data Export/Import
function initializeDataManagement() {
    const exportDataBtn = document.getElementById('exportDataBtn');
    const importDataBtn = document.getElementById('importDataBtn');
    const importDataFile = document.getElementById('importDataFile');
    
    if (exportDataBtn) {
        exportDataBtn.addEventListener('click', function() {
            exportData();
        });
    }
    
    if (importDataBtn && importDataFile) {
        importDataBtn.addEventListener('click', function() {
            if (importDataFile.files.length === 0) {
                showToast('Please select a file to import', 'error');
                return;
            }
            
            const file = importDataFile.files[0];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                try {
                    const data = JSON.parse(e.target.result);
                    importData(data);
                } catch (error) {
                    showToast('Error importing data: ' + error.message, 'error');
                }
            };
            
            reader.readAsText(file);
        });
    }
}

// Export Data
function exportData() {
    const data = DataStorage.exportData();
    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    
    const exportFileDefaultName = 'mental_health_journal_data.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    showToast('Data exported successfully');
}

// Import Data
function importData(data) {
    try {
        DataStorage.importData(data);
        
        // Reload all data
        loadInitialData();
        
        // Show success message
        showToast('Data imported successfully');
        
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('dataModal')).hide();
    } catch (error) {
        showToast('Error importing data: ' + error.message, 'error');
    }
}

// Load Initial Data
function loadInitialData() {
    // Load tags for all pages
    loadTags();
    
    // Load dashboard data
    loadDashboardData();
}

// Helper Functions
function getCurrentWeekNumber() {
    const now = new Date();
    const firstDayOfYear = new Date(now.getFullYear(), 0, 1);
    const pastDaysOfYear = (now - firstDayOfYear) / 86400000;
    return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Data Loading Functions
function loadDataForWeek(week, year) {
    // Load journal entries for the selected week
    const journals = JournalStorage.getJournalsByWeekYear(week, year);
    updateJournalEntriesForWeek(journals);
}

function loadDashboardData() {
    // Get current year
    const settings = SettingsStorage.getSettings();
    const currentYear = settings.currentYear || new Date().getFullYear();
    
    // Load recent journal entries
    const allJournals = JournalStorage.getAllJournals();
    updateRecentEntries(allJournals.slice(0, 3));
    
    // Load weekly mood chart data
    const moodData = AnalyticsStorage.getMoodAnalytics(currentYear);
    updateWeeklyMoodChart(moodData);
    
    // Load tag cloud
    const tagData = TagStorage.getTagAnalytics(currentYear);
    updateTagCloud(tagData);
}

// Update UI Functions
function updateRecentEntries(entries) {
    const recentEntriesContainer = document.getElementById('recentEntries');
    if (!recentEntriesContainer) return;
    
    if (entries.length === 0) {
        recentEntriesContainer.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-journal-text"></i>
                <p>No journal entries yet</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    entries.forEach(entry => {
        // Get tag objects for this entry
        const entryTags = entry.tags.map(tagId => {
            return TagStorage.getTagById(tagId);
        }).filter(tag => tag !== null);
        
        html += `
            <div class="recent-entry" data-id="${entry.id}">
                <div class="recent-entry-header">
                    <h6 class="recent-entry-title">${entry.title}</h6>
                    <span class="recent-entry-date">${formatDate(entry.created_at)}</span>
                </div>
                <div class="recent-entry-tags">
                    ${entryTags.map(tag => `
                        <span class="tag" style="background-color: ${tag.color}">${tag.name}</span>
                    `).join('')}
                </div>
            </div>
        `;
    });
    
    recentEntriesContainer.innerHTML = html;
    
    // Add click event to view entry
    const recentEntryElements = recentEntriesContainer.querySelectorAll('.recent-entry');
    recentEntryElements.forEach(element => {
        element.addEventListener('click', function() {
            const entryId = this.getAttribute('data-id');
            viewJournalEntry(entryId);
        });
    });
}

function updateWeeklyMoodChart(data) {
    const ctx = document.getElementById('weeklyMoodChart');
    if (!ctx) return;
    
    // Clear any existing chart
    if (window.weeklyMoodChart) {
        window.weeklyMoodChart.destroy();
    }
    
    // If no data, show placeholder
    if (data.length === 0) {
        ctx.parentNode.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-graph-up"></i>
                <p>No mood data available</p>
                <small>Add journal entries with mood ratings to see your chart</small>
            </div>
        `;
        return;
    }
    
    // Prepare data for chart
    const weeks = data.map(item => `Week ${item.week}`);
    const moodScores = data.map(item => item.average_mood);
    const energyLevels = data.map(item => item.average_energy);
    
    // Create chart
    window.weeklyMoodChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: weeks,
            datasets: [
                {
                    label: 'Mood',
                    data: moodScores,
                    borderColor: '#5b6af5',
                    backgroundColor: 'rgba(91, 106, 245, 0.1)',
                    tension: 0.3,
                    fill: true
                },
                {
                    label: 'Energy',
                    data: energyLevels,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    tension: 0.3,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                y: {
                    min: 0,
                    max: 10,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

function updateTagCloud(tags) {
    const tagCloud = document.getElementById('tagCloud');
    if (!tagCloud) return;
    
    if (tags.length === 0) {
        tagCloud.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-tags"></i>
                <p>No tags yet</p>
            </div>
        `;
        return;
    }
    
    // Filter tags with usage count > 0
    const usedTags = tags.filter(tag => tag.count > 0);
    
    if (usedTags.length === 0) {
        tagCloud.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-tags"></i>
                <p>No tags used in journal entries yet</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    usedTags.forEach(tag => {
        html += `<span class="tag" style="background-color: ${tag.color}">${tag.name} (${tag.count})</span>`;
    });
    
    tagCloud.innerHTML = html;
}

// Journal Entry Modal Functions
function openJournalEntryModal(journalId = null) {
    // Reset form
    document.getElementById('journalEntryForm').reset();
    document.getElementById('journalId').value = '';
    
    const modalTitle = document.getElementById('journalEntryModalLabel');
    const saveButton = document.getElementById('saveJournalEntry');
    
    if (journalId) {
        // Edit existing entry
        modalTitle.textContent = 'Edit Journal Entry';
        
        // Load journal data
        const journal = JournalStorage.getJournalById(journalId);
        
        if (journal) {
            document.getElementById('journalId').value = journal.id;
            document.getElementById('journalTitle').value = journal.title;
            document.getElementById('journalContent').value = journal.content;
            
            // Set mood data if available
            if (journal.mood_entries.length > 0) {
                const mood = journal.mood_entries[0];
                document.getElementById('journalMoodScore').value = mood.mood_score;
                document.getElementById('journalEnergyLevel').value = mood.energy_level;
                document.getElementById('journalMoodNotes').value = mood.notes || '';
                
                // Update slider displays
                document.querySelector('#journalMoodScore').closest('.mood-slider-container').querySelector('.mood-value').textContent = `${mood.mood_score}/10`;
                document.querySelector('#journalEnergyLevel').closest('.mood-slider-container').querySelector('.energy-value').textContent = `${mood.energy_level}/10`;
            }
            
            // Set selected tags
            updateJournalTagsSelector(journal.tags);
        }
    } else {
        // New entry
        modalTitle.textContent = 'New Journal Entry';
        updateJournalTagsSelector([]);
    }
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('journalEntryModal'));
    modal.show();
    
    // Save button event
    saveButton.onclick = function() {
        saveJournalEntry();
    };
}

function updateJournalTagsSelector(selectedTagIds) {
    const tagsSelector = document.getElementById('journalTagsSelector');
    if (!tagsSelector) return;
    
    // Load all tags
    const tags = TagStorage.getAllTags();
    
    let html = '';
    tags.forEach(tag => {
        const isSelected = selectedTagIds.includes(tag.id);
        html += `
            <span class="tag tag-selector ${isSelected ? 'selected' : ''}" 
                  data-id="${tag.id}" 
                  style="background-color: ${tag.color}">
                ${tag.name}
            </span>
        `;
    });
    
    if (html === '') {
        html = `
            <div class="placeholder-message" style="padding: 1rem;">
                <p>No tags available. Create tags in the Tags section.</p>
            </div>
        `;
    }
    
    tagsSelector.innerHTML = html;
    
    // Add click event to toggle selection
    const tagElements = tagsSelector.querySelectorAll('.tag-selector');
    tagElements.forEach(element => {
        element.addEventListener('click', function() {
            this.classList.toggle('selected');
        });
    });
}

function saveJournalEntry() {
    // Get form data
    const journalId = document.getElementById('journalId').value;
    const title = document.getElementById('journalTitle').value;
    const content = document.getElementById('journalContent').value;
    const moodScore = parseInt(document.getElementById('journalMoodScore').value);
    const energyLevel = parseInt(document.getElementById('journalEnergyLevel').value);
    const moodNotes = document.getElementById('journalMoodNotes').value;
    
    // Validate required fields
    if (!title || !content) {
        showToast('Please fill in all required fields', 'error');
        return;
    }
    
    // Get selected tags
    const selectedTags = [];
    document.querySelectorAll('#journalTagsSelector .tag-selector.selected').forEach(tag => {
        selectedTags.push(tag.getAttribute('data-id'));
    });
    
    try {
        if (journalId) {
            // Update existing journal
            JournalStorage.updateJournal(journalId, {
                title: title,
                content: content,
                tags: selectedTags
            });
            
            // Update mood if it exists, or add new one
            const journal = JournalStorage.getJournalById(journalId);
            if (journal.mood_entries.length > 0) {
                JournalStorage.updateMoodEntry(journal.mood_entries[0].id, {
                    mood_score: moodScore,
                    energy_level: energyLevel,
                    notes: moodNotes
                });
            } else {
                JournalStorage.addMoodEntry(journalId, {
                    mood_score: moodScore,
                    energy_level: energyLevel,
                    notes: moodNotes
                });
            }
        } else {
            // Create new journal with mood
            JournalStorage.createJournal({
                title: title,
                content: content,
                tags: selectedTags,
                mood: {
                    mood_score: moodScore,
                    energy_level: energyLevel,
                    notes: moodNotes
                }
            });
        }
        
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('journalEntryModal')).hide();
        
        // Refresh data
        const settings = SettingsStorage.getSettings();
        loadDataForWeek(settings.currentWeek, settings.currentYear);
        loadDashboardData();
        
        // Show success message
        showToast('Journal entry saved successfully!');
    } catch (error) {
        showToast('Error saving journal entry: ' + error.message, 'error');
    }
}

// View Journal Entry
function viewJournalEntry(journalId) {
    const journal = JournalStorage.getJournalById(journalId);
    
    if (!journal) {
        showToast('Journal entry not found', 'error');
        return;
    }
    
    // Populate view modal
    document.getElementById('viewJournalTitle').textContent = journal.title;
    document.getElementById('viewJournalDate').textContent = formatDate(journal.created_at);
    document.getElementById('viewJournalContent').textContent = journal.content;
    
    // Get tag objects for this entry
    const entryTags = journal.tags.map(tagId => {
        return TagStorage.getTagById(tagId);
    }).filter(tag => tag !== null);
    
    // Set tags
    const tagsContainer = document.getElementById('viewJournalTags');
    tagsContainer.innerHTML = '';
    entryTags.forEach(tag => {
        const tagElement = document.createElement('span');
        tagElement.className = 'tag';
        tagElement.style.backgroundColor = tag.color;
        tagElement.textContent = tag.name;
        tagsContainer.appendChild(tagElement);
    });
    
    // Set mood data if available
    if (journal.mood_entries && journal.mood_entries.length > 0) {
        const mood = journal.mood_entries[0];
        document.getElementById('viewJournalMood').textContent = `${mood.mood_score}/10`;
        document.getElementById('viewJournalEnergy').textContent = `${mood.energy_level}/10`;
    } else {
        document.getElementById('viewJournalMood').textContent = 'Not recorded';
        document.getElementById('viewJournalEnergy').textContent = 'Not recorded';
    }
    
    // Set data-id for edit and delete buttons
    document.getElementById('editJournalBtn').setAttribute('data-id', journal.id);
    document.getElementById('deleteJournalBtn').setAttribute('data-id', journal.id);
    
    // Add event listeners
    document.getElementById('editJournalBtn').onclick = function() {
        // Close view modal
        bootstrap.Modal.getInstance(document.getElementById('viewJournalModal')).hide();
        // Open edit modal
        openJournalEntryModal(journalId);
    };
    
    document.getElementById('deleteJournalBtn').onclick = function() {
        confirmDeleteJournal(journalId);
    };
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('viewJournalModal'));
    modal.show();
}

// Confirm Delete Journal
function confirmDeleteJournal(journalId) {
    // Set confirmation message
    document.getElementById('confirmationMessage').textContent = 'Are you sure you want to delete this journal entry? This action cannot be undone.';
    
    // Set confirm action
    const confirmAction = document.getElementById('confirmAction');
    confirmAction.onclick = function() {
        deleteJournalEntry(journalId);
    };
    
    // Show confirmation modal
    const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    modal.show();
}

// Delete Journal Entry
function deleteJournalEntry(journalId) {
    try {
        JournalStorage.deleteJournal(journalId);
        
        // Close modals
        bootstrap.Modal.getInstance(document.getElementById('confirmationModal')).hide();
        bootstrap.Modal.getInstance(document.getElementById('viewJournalModal')).hide();
        
        // Refresh data
        const settings = SettingsStorage.getSettings();
        loadDataForWeek(settings.currentWeek, settings.currentYear);
        loadDashboardData();
        
        // Show success message
        showToast('Journal entry deleted successfully!');
    } catch (error) {
        showToast('Error deleting journal entry: ' + error.message, 'error');
    }
}

// Create Quick Mood Entry
function createQuickMoodEntry(moodScore, energyLevel, moodNotes) {
    // Get current date info
    const now = new Date();
    const weekNumber = getCurrentWeekNumber();
    const year = now.getFullYear();
    
    try {
        // Create a new journal entry with mood data
        JournalStorage.createJournal({
            title: `Mood Check-in - ${formatDate(now)}`,
            content: moodNotes || 'Quick mood check-in',
            week_number: weekNumber,
            year: year,
            tags: [],
            mood: {
                mood_score: parseInt(moodScore),
                energy_level: parseInt(energyLevel),
                notes: moodNotes
            }
        });
        
        // Reset form
        document.getElementById('quickMoodForm').reset();
        document.getElementById('moodScore').value = 5;
        document.getElementById('energyLevel').value = 5;
        document.querySelector('#moodScore').closest('.mood-slider-container').querySelector('.mood-value').textContent = '5/10';
        document.querySelector('#energyLevel').closest('.mood-slider-container').querySelector('.energy-value').textContent = '5/10';
        
        // Refresh dashboard data
        loadDashboardData();
        
        // Show success message
        showToast('Mood check-in saved successfully!');
    } catch (error) {
        showToast('Error saving mood check-in: ' + error.message, 'error');
    }
}

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.getElementById('appToast');
    const toastMessage = document.getElementById('toastMessage');
    
    if (toast && toastMessage) {
        // Set message
        toastMessage.textContent = message;
        
        // Set type
        toast.classList.remove('bg-success', 'bg-danger');
        toast.classList.add(type === 'error' ? 'bg-danger' : 'bg-success');
        
        // Show toast
        const bsToast = bootstrap.Toast.getInstance(toast) || new bootstrap.Toast(toast);
        bsToast.show();
    } else {
        // Fallback to alert if toast elements not found
        alert(message);
    }
}

// Export functions for use in other modules
window.app = {
    openJournalEntryModal,
    viewJournalEntry,
    showToast,
    navigateToPage: function(pageId) {
        const navLink = document.querySelector(`[data-page="${pageId}"]`);
        if (navLink) {
            navLink.click();
        }
    }
};
