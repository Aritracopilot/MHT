// Tags management functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tags management events
    initializeTagsEvents();
    
    // Load tags if on tags page
    if (document.getElementById('tags-page').classList.contains('active')) {
        loadTagsManagement();
    }
});

// Initialize Tags Events
function initializeTagsEvents() {
    // New tag form submission
    const newTagForm = document.getElementById('newTagForm');
    if (newTagForm) {
        newTagForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const tagName = document.getElementById('tagName').value;
            const tagColor = document.getElementById('tagColor').value;
            
            createTag(tagName, tagColor);
        });
    }
    
    // Save tag edit button
    const saveTagEdit = document.getElementById('saveTagEdit');
    if (saveTagEdit) {
        saveTagEdit.addEventListener('click', function() {
            const tagId = document.getElementById('editTagId').value;
            const tagName = document.getElementById('editTagName').value;
            const tagColor = document.getElementById('editTagColor').value;
            
            updateTag(tagId, tagName, tagColor);
        });
    }
}

// Load Tags Management
function loadTagsManagement() {
    loadTagsList();
    loadTagUsageChart();
}

// Load Tags List
function loadTagsList() {
    const tagsListContainer = document.getElementById('tagsList');
    if (!tagsListContainer) return;
    
    // Show loading state
    tagsListContainer.innerHTML = `
        <div class="text-center p-3">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading tags...</p>
        </div>
    `;
    
    // Get all tags
    const tags = TagStorage.getAllTags();
    
    // Update tags list
    updateTagsList(tags);
}

// Update Tags List
function updateTagsList(tags) {
    const tagsListContainer = document.getElementById('tagsList');
    if (!tagsListContainer) return;
    
    if (tags.length === 0) {
        tagsListContainer.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-tags"></i>
                <p>No tags yet</p>
                <p class="text-muted">Create tags to organize your journal entries</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    tags.forEach(tag => {
        html += `
            <div class="tag-item">
                <div class="tag-item-name">
                    <div class="tag-color" style="background-color: ${tag.color}"></div>
                    <span>${tag.name}</span>
                </div>
                <div class="tag-item-actions">
                    <button class="btn btn-sm btn-outline-primary edit-tag-btn" data-id="${tag.id}" data-name="${tag.name}" data-color="${tag.color}">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-tag-btn" data-id="${tag.id}" data-name="${tag.name}">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            </div>
        `;
    });
    
    tagsListContainer.innerHTML = html;
    
    // Add event listeners to edit and delete buttons
    const editButtons = tagsListContainer.querySelectorAll('.edit-tag-btn');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tagId = this.getAttribute('data-id');
            const tagName = this.getAttribute('data-name');
            const tagColor = this.getAttribute('data-color');
            
            openEditTagModal(tagId, tagName, tagColor);
        });
    });
    
    const deleteButtons = tagsListContainer.querySelectorAll('.delete-tag-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tagId = this.getAttribute('data-id');
            const tagName = this.getAttribute('data-name');
            
            confirmDeleteTag(tagId, tagName);
        });
    });
}

// Load Tag Usage Chart
function loadTagUsageChart() {
    const ctx = document.getElementById('tagUsageChart');
    if (!ctx) return;
    
    // Get current year
    const settings = SettingsStorage.getSettings();
    const currentYear = settings.currentYear || new Date().getFullYear();
    
    // Get tag usage data
    const tagData = TagStorage.getTagAnalytics(currentYear);
    
    // Update tag usage chart
    updateTagUsageChart(tagData);
}

// Update Tag Usage Chart
function updateTagUsageChart(tags) {
    const ctx = document.getElementById('tagUsageChart');
    if (!ctx) return;
    
    // Filter tags with usage count > 0
    const usedTags = tags.filter(tag => tag.count > 0);
    
    if (usedTags.length === 0) {
        ctx.parentNode.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-tags"></i>
                <p>No tags used in journal entries yet</p>
                <small>Add tags to your journal entries to see usage statistics</small>
            </div>
        `;
        return;
    }
    
    // Clear any existing chart
    if (window.tagUsageChart) {
        window.tagUsageChart.destroy();
    }
    
    // Sort tags by usage count (descending)
    usedTags.sort((a, b) => b.count - a.count);
    
    // Limit to top 10 tags
    const topTags = usedTags.slice(0, 10);
    
    // Prepare data for chart
    const labels = topTags.map(tag => tag.name);
    const counts = topTags.map(tag => tag.count);
    const colors = topTags.map(tag => tag.color);
    
    // Create chart
    window.tagUsageChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Usage Count',
                data: counts,
                backgroundColor: colors,
                borderColor: colors.map(color => adjustColor(color, -20)),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        title: function(tooltipItems) {
                            return tooltipItems[0].label;
                        },
                        label: function(context) {
                            return `Used in ${context.raw} entries`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

// Create Tag
function createTag(name, color) {
    // Validate input
    if (!name || !color) {
        window.app.showToast('Please enter a tag name and select a color.', 'error');
        return;
    }
    
    try {
        // Create tag
        TagStorage.createTag({
            name: name,
            color: color
        });
        
        // Reset form
        document.getElementById('newTagForm').reset();
        document.getElementById('tagColor').value = '#6c757d';
        
        // Refresh tags list
        loadTagsList();
        loadTagUsageChart();
        
        // Show success message
        window.app.showToast('Tag created successfully!');
    } catch (error) {
        window.app.showToast(error.message || 'Error creating tag. Please try again.', 'error');
    }
}

// Open Edit Tag Modal
function openEditTagModal(tagId, tagName, tagColor) {
    // Set form values
    document.getElementById('editTagId').value = tagId;
    document.getElementById('editTagName').value = tagName;
    document.getElementById('editTagColor').value = tagColor;
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('editTagModal'));
    modal.show();
}

// Update Tag
function updateTag(tagId, name, color) {
    // Validate input
    if (!tagId || !name || !color) {
        window.app.showToast('Please enter a tag name and select a color.', 'error');
        return;
    }
    
    try {
        // Update tag
        TagStorage.updateTag(tagId, {
            name: name,
            color: color
        });
        
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('editTagModal')).hide();
        
        // Refresh tags list
        loadTagsList();
        loadTagUsageChart();
        
        // Show success message
        window.app.showToast('Tag updated successfully!');
    } catch (error) {
        window.app.showToast(error.message || 'Error updating tag. Please try again.', 'error');
    }
}

// Confirm Delete Tag
function confirmDeleteTag(tagId, tagName) {
    // Set confirmation message
    document.getElementById('confirmationMessage').innerHTML = `
        Are you sure you want to delete the tag <strong>${tagName}</strong>?<br>
        This will remove the tag from all journal entries.
    `;
    
    // Set confirm action
    const confirmAction = document.getElementById('confirmAction');
    confirmAction.onclick = function() {
        deleteTag(tagId);
    };
    
    // Show confirmation modal
    const modal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    modal.show();
}

// Delete Tag
function deleteTag(tagId) {
    try {
        // Delete tag
        TagStorage.deleteTag(tagId);
        
        // Close modal
        bootstrap.Modal.getInstance(document.getElementById('confirmationModal')).hide();
        
        // Refresh tags list
        loadTagsList();
        loadTagUsageChart();
        
        // Show success message
        window.app.showToast('Tag deleted successfully!');
    } catch (error) {
        window.app.showToast('Error deleting tag. Please try again.', 'error');
    }
}

// Helper function to adjust color brightness
function adjustColor(color, amount) {
    // Convert hex to RGB
    let hex = color;
    if (hex.startsWith('#')) {
        hex = hex.slice(1);
    }
    
    // Parse the hex values
    let r = parseInt(hex.substr(0, 2), 16);
    let g = parseInt(hex.substr(2, 2), 16);
    let b = parseInt(hex.substr(4, 2), 16);
    
    // Adjust the values
    r = Math.max(0, Math.min(255, r + amount));
    g = Math.max(0, Math.min(255, g + amount));
    b = Math.max(0, Math.min(255, b + amount));
    
    // Convert back to hex
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}
