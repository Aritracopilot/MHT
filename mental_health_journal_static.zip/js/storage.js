// Storage management for the Mental Health Journal app
// This module handles all localStorage operations for journals, tags, and mood entries

// Storage keys
const STORAGE_KEYS = {
    JOURNALS: 'mhj_journals',
    TAGS: 'mhj_tags',
    SETTINGS: 'mhj_settings'
};

// Data structure initialization
function initializeStorage() {
    // Check if storage is already initialized
    if (!localStorage.getItem(STORAGE_KEYS.JOURNALS)) {
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify([]));
    }
    
    if (!localStorage.getItem(STORAGE_KEYS.TAGS)) {
        localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify([]));
    }
    
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify({
            currentWeek: getCurrentWeekNumber(),
            currentYear: new Date().getFullYear()
        }));
    }
}

// Journal CRUD operations
const JournalStorage = {
    // Get all journals
    getAllJournals: function() {
        const journals = JSON.parse(localStorage.getItem(STORAGE_KEYS.JOURNALS) || '[]');
        return journals.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },
    
    // Get journal by ID
    getJournalById: function(id) {
        const journals = this.getAllJournals();
        return journals.find(journal => journal.id === id) || null;
    },
    
    // Get journals by week and year
    getJournalsByWeekYear: function(week, year) {
        const journals = this.getAllJournals();
        return journals.filter(journal => journal.week_number === week && journal.year === year);
    },
    
    // Get journals by year
    getJournalsByYear: function(year) {
        const journals = this.getAllJournals();
        return journals.filter(journal => journal.year === year);
    },
    
    // Create new journal
    createJournal: function(journalData) {
        const journals = this.getAllJournals();
        
        // Generate a unique ID
        const newId = Date.now().toString();
        
        // Create new journal object
        const newJournal = {
            id: newId,
            title: journalData.title,
            content: journalData.content,
            week_number: journalData.week_number || getCurrentWeekNumber(),
            year: journalData.year || new Date().getFullYear(),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            tags: journalData.tags || [],
            mood_entries: []
        };
        
        // Add mood entry if provided
        if (journalData.mood) {
            const moodEntry = {
                id: Date.now().toString() + '-mood',
                journal_id: newId,
                mood_score: journalData.mood.mood_score || 5,
                energy_level: journalData.mood.energy_level || 5,
                notes: journalData.mood.notes || '',
                created_at: new Date().toISOString()
            };
            
            newJournal.mood_entries.push(moodEntry);
        }
        
        // Add to journals array
        journals.push(newJournal);
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
        
        return newJournal;
    },
    
    // Update existing journal
    updateJournal: function(id, journalData) {
        const journals = this.getAllJournals();
        const index = journals.findIndex(journal => journal.id === id);
        
        if (index === -1) {
            return null;
        }
        
        // Update journal fields
        const updatedJournal = { ...journals[index] };
        
        if (journalData.title !== undefined) {
            updatedJournal.title = journalData.title;
        }
        
        if (journalData.content !== undefined) {
            updatedJournal.content = journalData.content;
        }
        
        if (journalData.week_number !== undefined) {
            updatedJournal.week_number = journalData.week_number;
        }
        
        if (journalData.year !== undefined) {
            updatedJournal.year = journalData.year;
        }
        
        if (journalData.tags !== undefined) {
            updatedJournal.tags = journalData.tags;
        }
        
        updatedJournal.updated_at = new Date().toISOString();
        
        // Update in array
        journals[index] = updatedJournal;
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
        
        return updatedJournal;
    },
    
    // Delete journal
    deleteJournal: function(id) {
        const journals = this.getAllJournals();
        const filteredJournals = journals.filter(journal => journal.id !== id);
        
        if (filteredJournals.length === journals.length) {
            return false; // Journal not found
        }
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(filteredJournals));
        
        return true;
    },
    
    // Add mood entry to journal
    addMoodEntry: function(journalId, moodData) {
        const journals = this.getAllJournals();
        const index = journals.findIndex(journal => journal.id === journalId);
        
        if (index === -1) {
            return null;
        }
        
        // Create mood entry
        const moodEntry = {
            id: Date.now().toString() + '-mood',
            journal_id: journalId,
            mood_score: moodData.mood_score || 5,
            energy_level: moodData.energy_level || 5,
            notes: moodData.notes || '',
            created_at: new Date().toISOString()
        };
        
        // Add to journal
        journals[index].mood_entries.push(moodEntry);
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
        
        return moodEntry;
    },
    
    // Update mood entry
    updateMoodEntry: function(moodId, moodData) {
        const journals = this.getAllJournals();
        
        // Find journal containing the mood entry
        for (let i = 0; i < journals.length; i++) {
            const moodIndex = journals[i].mood_entries.findIndex(mood => mood.id === moodId);
            
            if (moodIndex !== -1) {
                // Update mood entry
                if (moodData.mood_score !== undefined) {
                    journals[i].mood_entries[moodIndex].mood_score = moodData.mood_score;
                }
                
                if (moodData.energy_level !== undefined) {
                    journals[i].mood_entries[moodIndex].energy_level = moodData.energy_level;
                }
                
                if (moodData.notes !== undefined) {
                    journals[i].mood_entries[moodIndex].notes = moodData.notes;
                }
                
                // Save to localStorage
                localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
                
                return journals[i].mood_entries[moodIndex];
            }
        }
        
        return null;
    },
    
    // Delete mood entry
    deleteMoodEntry: function(moodId) {
        const journals = this.getAllJournals();
        
        // Find journal containing the mood entry
        for (let i = 0; i < journals.length; i++) {
            const initialLength = journals[i].mood_entries.length;
            journals[i].mood_entries = journals[i].mood_entries.filter(mood => mood.id !== moodId);
            
            if (journals[i].mood_entries.length < initialLength) {
                // Save to localStorage
                localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
                return true;
            }
        }
        
        return false;
    }
};

// Tag CRUD operations
const TagStorage = {
    // Get all tags
    getAllTags: function() {
        return JSON.parse(localStorage.getItem(STORAGE_KEYS.TAGS) || '[]');
    },
    
    // Get tag by ID
    getTagById: function(id) {
        const tags = this.getAllTags();
        return tags.find(tag => tag.id === id) || null;
    },
    
    // Create new tag
    createTag: function(tagData) {
        const tags = this.getAllTags();
        
        // Check if tag with same name already exists
        if (tags.some(tag => tag.name.toLowerCase() === tagData.name.toLowerCase())) {
            throw new Error('Tag with this name already exists');
        }
        
        // Create new tag
        const newTag = {
            id: Date.now().toString(),
            name: tagData.name,
            color: tagData.color || '#6c757d',
            created_at: new Date().toISOString()
        };
        
        // Add to tags array
        tags.push(newTag);
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify(tags));
        
        return newTag;
    },
    
    // Update tag
    updateTag: function(id, tagData) {
        const tags = this.getAllTags();
        const index = tags.findIndex(tag => tag.id === id);
        
        if (index === -1) {
            return null;
        }
        
        // Check if new name already exists in another tag
        if (tagData.name && tags.some(tag => tag.id !== id && tag.name.toLowerCase() === tagData.name.toLowerCase())) {
            throw new Error('Tag with this name already exists');
        }
        
        // Update tag
        if (tagData.name !== undefined) {
            tags[index].name = tagData.name;
        }
        
        if (tagData.color !== undefined) {
            tags[index].color = tagData.color;
        }
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify(tags));
        
        return tags[index];
    },
    
    // Delete tag
    deleteTag: function(id) {
        const tags = this.getAllTags();
        const filteredTags = tags.filter(tag => tag.id !== id);
        
        if (filteredTags.length === tags.length) {
            return false; // Tag not found
        }
        
        // Save to localStorage
        localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify(filteredTags));
        
        // Remove tag from all journals
        const journals = JournalStorage.getAllJournals();
        let journalsUpdated = false;
        
        for (let i = 0; i < journals.length; i++) {
            const initialTagsLength = journals[i].tags.length;
            journals[i].tags = journals[i].tags.filter(tagId => tagId !== id);
            
            if (journals[i].tags.length < initialTagsLength) {
                journalsUpdated = true;
            }
        }
        
        if (journalsUpdated) {
            localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journals));
        }
        
        return true;
    },
    
    // Get tag usage analytics
    getTagAnalytics: function(year) {
        const tags = this.getAllTags();
        const journals = JournalStorage.getJournalsByYear(year);
        
        return tags.map(tag => {
            // Count journals with this tag for the specified year
            const count = journals.filter(journal => journal.tags.includes(tag.id)).length;
            
            return {
                id: tag.id,
                name: tag.name,
                color: tag.color,
                count: count
            };
        });
    }
};

// Analytics operations
const AnalyticsStorage = {
    // Get mood analytics data
    getMoodAnalytics: function(year) {
        const journals = JournalStorage.getJournalsByYear(year);
        
        // Organize data by week
        const weeksData = {};
        
        journals.forEach(journal => {
            journal.mood_entries.forEach(entry => {
                const week = journal.week_number;
                
                if (!weeksData[week]) {
                    weeksData[week] = {
                        mood_scores: [],
                        energy_levels: []
                    };
                }
                
                weeksData[week].mood_scores.push(entry.mood_score);
                weeksData[week].energy_levels.push(entry.energy_level);
            });
        });
        
        // Calculate averages for each week
        const result = [];
        
        for (const week in weeksData) {
            const data = weeksData[week];
            const avgMood = data.mood_scores.reduce((sum, val) => sum + val, 0) / data.mood_scores.length;
            const avgEnergy = data.energy_levels.reduce((sum, val) => sum + val, 0) / data.energy_levels.length;
            
            result.push({
                week: parseInt(week),
                average_mood: parseFloat(avgMood.toFixed(1)),
                average_energy: parseFloat(avgEnergy.toFixed(1)),
                entry_count: data.mood_scores.length
            });
        }
        
        // Sort by week number
        result.sort((a, b) => a.week - b.week);
        
        return result;
    }
};

// Settings operations
const SettingsStorage = {
    // Get all settings
    getSettings: function() {
        return JSON.parse(localStorage.getItem(STORAGE_KEYS.SETTINGS) || '{}');
    },
    
    // Update settings
    updateSettings: function(settings) {
        const currentSettings = this.getSettings();
        const updatedSettings = { ...currentSettings, ...settings };
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updatedSettings));
        return updatedSettings;
    }
};

// Data export/import
const DataStorage = {
    // Export all data
    exportData: function() {
        return {
            journals: JournalStorage.getAllJournals(),
            tags: TagStorage.getAllTags(),
            settings: SettingsStorage.getSettings(),
            exportDate: new Date().toISOString()
        };
    },
    
    // Import data
    importData: function(data) {
        // Validate data structure
        if (!data.journals || !Array.isArray(data.journals) || 
            !data.tags || !Array.isArray(data.tags)) {
            throw new Error('Invalid data format');
        }
        
        // Import data
        localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(data.journals));
        localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify(data.tags));
        
        if (data.settings) {
            localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings));
        }
        
        return true;
    },
    
    // Clear all data
    clearData: function() {
        localStorage.removeItem(STORAGE_KEYS.JOURNALS);
        localStorage.removeItem(STORAGE_KEYS.TAGS);
        localStorage.removeItem(STORAGE_KEYS.SETTINGS);
        initializeStorage();
        return true;
    }
};

// Helper functions
function getCurrentWeekNumber() {
    const now = new Date();
    const firstDayOfYear = new Date(now.getFullYear(), 0, 1);
    const pastDaysOfYear = (now - firstDayOfYear) / 86400000;
    return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
}

// Initialize storage on load
document.addEventListener('DOMContentLoaded', function() {
    initializeStorage();
});

// Export storage modules
window.JournalStorage = JournalStorage;
window.TagStorage = TagStorage;
window.AnalyticsStorage = AnalyticsStorage;
window.SettingsStorage = SettingsStorage;
window.DataStorage = DataStorage;
