// Mood tracking and chart functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize mood tracking events
    initializeMoodEvents();
    
    // Load mood analytics if on mood tracker page
    if (document.getElementById('mood-tracker-page').classList.contains('active')) {
        loadMoodAnalytics();
    }
});

// Initialize Mood Events
function initializeMoodEvents() {
    // Year selector events are handled in app.js
}

// Load Mood Analytics
function loadMoodAnalytics(year = null) {
    // If year not provided, use current year
    if (!year) {
        const settings = SettingsStorage.getSettings();
        year = settings.currentYear || new Date().getFullYear();
    }
    
    // Update year display
    const currentYearDisplay = document.getElementById('currentYearDisplay');
    if (currentYearDisplay) {
        currentYearDisplay.textContent = year;
    }
    
    // Get mood analytics data
    const data = AnalyticsStorage.getMoodAnalytics(year);
    
    // Update UI
    updateYearlyMoodChart(data);
    updateMoodStats(data);
    identifyMoodPatterns(data);
}

// Update Yearly Mood Chart
function updateYearlyMoodChart(data) {
    const ctx = document.getElementById('yearlyMoodChart');
    if (!ctx) return;
    
    // Clear any existing chart
    if (window.yearlyMoodChart) {
        window.yearlyMoodChart.destroy();
    }
    
    // If no data, show placeholder
    if (data.length === 0) {
        ctx.parentNode.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-graph-up"></i>
                <p>No mood data available for this year</p>
                <small>Add journal entries with mood ratings to see your chart</small>
            </div>
        `;
        return;
    }
    
    // Prepare data for chart
    const weeks = data.map(item => `Week ${item.week}`);
    const moodScores = data.map(item => item.average_mood);
    const energyLevels = data.map(item => item.average_energy);
    const entryCounts = data.map(item => item.entry_count);
    
    // Create chart
    window.yearlyMoodChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: weeks,
            datasets: [
                {
                    label: 'Mood',
                    data: moodScores,
                    borderColor: '#5b6af5',
                    backgroundColor: 'rgba(91, 106, 245, 0.1)',
                    tension: 0.3,
                    fill: true,
                    yAxisID: 'y'
                },
                {
                    label: 'Energy',
                    data: energyLevels,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    tension: 0.3,
                    fill: true,
                    yAxisID: 'y'
                },
                {
                    label: 'Entries',
                    data: entryCounts,
                    type: 'bar',
                    backgroundColor: 'rgba(108, 117, 125, 0.2)',
                    borderColor: 'rgba(108, 117, 125, 0.6)',
                    borderWidth: 1,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    min: 0,
                    max: 10,
                    ticks: {
                        stepSize: 1
                    },
                    title: {
                        display: true,
                        text: 'Mood & Energy (1-10)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 0,
                    grid: {
                        drawOnChartArea: false
                    },
                    title: {
                        display: true,
                        text: 'Number of Entries'
                    },
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Update Mood Statistics
function updateMoodStats(data) {
    // Calculate average mood and energy
    let totalMood = 0;
    let totalEnergy = 0;
    let totalEntries = 0;
    let bestWeek = { week: 0, mood: 0 };
    
    data.forEach(item => {
        totalMood += item.average_mood * item.entry_count;
        totalEnergy += item.average_energy * item.entry_count;
        totalEntries += item.entry_count;
        
        if (item.average_mood > bestWeek.mood) {
            bestWeek = { week: item.week, mood: item.average_mood };
        }
    });
    
    const avgMood = totalEntries > 0 ? (totalMood / totalEntries).toFixed(1) : '-';
    const avgEnergy = totalEntries > 0 ? (totalEnergy / totalEntries).toFixed(1) : '-';
    
    // Update stats display
    document.getElementById('avgMood').textContent = avgMood;
    document.getElementById('avgEnergy').textContent = avgEnergy;
    document.getElementById('bestWeek').textContent = bestWeek.week > 0 ? `Week ${bestWeek.week}` : '-';
    document.getElementById('totalEntries').textContent = totalEntries;
}

// Identify Mood Patterns
function identifyMoodPatterns(data) {
    const patternsContainer = document.getElementById('moodPatterns');
    if (!patternsContainer) return;
    
    // Check if we have enough data for patterns
    if (data.length < 3 || data.reduce((sum, item) => sum + item.entry_count, 0) < 5) {
        patternsContainer.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-graph-up"></i>
                <p>Need more entries to identify patterns</p>
                <small>Add at least 5 entries across multiple weeks</small>
            </div>
        `;
        return;
    }
    
    // Analyze data for patterns
    const patterns = [];
    
    // Check for mood trends (increasing, decreasing, stable)
    const recentWeeks = data.filter(item => item.entry_count > 0).slice(-4);
    if (recentWeeks.length >= 3) {
        const moodValues = recentWeeks.map(item => item.average_mood);
        const moodDiff = moodValues[moodValues.length - 1] - moodValues[0];
        
        if (moodDiff > 1) {
            patterns.push({
                title: 'Improving Mood Trend',
                description: 'Your mood has been improving over the past few weeks.'
            });
        } else if (moodDiff < -1) {
            patterns.push({
                title: 'Declining Mood Trend',
                description: 'Your mood has been declining over the past few weeks.'
            });
        } else {
            patterns.push({
                title: 'Stable Mood',
                description: 'Your mood has been relatively stable recently.'
            });
        }
    }
    
    // Check for mood-energy correlation
    const moodEnergyCorrelation = calculateCorrelation(
        data.map(item => item.average_mood),
        data.map(item => item.average_energy)
    );
    
    if (moodEnergyCorrelation > 0.7) {
        patterns.push({
            title: 'Strong Mood-Energy Connection',
            description: 'Your mood and energy levels tend to rise and fall together.'
        });
    } else if (moodEnergyCorrelation < 0.3) {
        patterns.push({
            title: 'Independent Mood and Energy',
            description: 'Your mood and energy levels appear to vary independently.'
        });
    }
    
    // Check for consistency
    const moodVariance = calculateVariance(data.map(item => item.average_mood));
    if (moodVariance < 1) {
        patterns.push({
            title: 'Consistent Mood',
            description: 'Your mood shows little variation week to week.'
        });
    } else if (moodVariance > 3) {
        patterns.push({
            title: 'Variable Mood',
            description: 'Your mood shows significant variation week to week.'
        });
    }
    
    // Display patterns
    if (patterns.length === 0) {
        patternsContainer.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-graph-up"></i>
                <p>No clear patterns detected yet</p>
                <small>Continue adding entries for more insights</small>
            </div>
        `;
    } else {
        let html = '';
        patterns.forEach(pattern => {
            html += `
                <div class="pattern-item">
                    <div class="pattern-title">${pattern.title}</div>
                    <div class="pattern-description">${pattern.description}</div>
                </div>
            `;
        });
        patternsContainer.innerHTML = html;
    }
}

// Helper Functions
function calculateCorrelation(x, y) {
    // Filter out entries where either value is 0
    const filteredData = x.map((value, index) => [value, y[index]])
        .filter(pair => pair[0] > 0 && pair[1] > 0);
    
    if (filteredData.length < 3) return 0;
    
    const xValues = filteredData.map(pair => pair[0]);
    const yValues = filteredData.map(pair => pair[1]);
    
    const xMean = xValues.reduce((sum, val) => sum + val, 0) / xValues.length;
    const yMean = yValues.reduce((sum, val) => sum + val, 0) / yValues.length;
    
    const xDiff = xValues.map(val => val - xMean);
    const yDiff = yValues.map(val => val - yMean);
    
    const numerator = xDiff.reduce((sum, val, i) => sum + val * yDiff[i], 0);
    
    const xDiffSquared = xDiff.map(val => val * val);
    const yDiffSquared = yDiff.map(val => val * val);
    
    const denominator = Math.sqrt(
        xDiffSquared.reduce((sum, val) => sum + val, 0) *
        yDiffSquared.reduce((sum, val) => sum + val, 0)
    );
    
    return denominator === 0 ? 0 : numerator / denominator;
}

function calculateVariance(values) {
    // Filter out zero values
    const filteredValues = values.filter(val => val > 0);
    
    if (filteredValues.length < 2) return 0;
    
    const mean = filteredValues.reduce((sum, val) => sum + val, 0) / filteredValues.length;
    const squaredDiffs = filteredValues.map(val => Math.pow(val - mean, 2));
    return squaredDiffs.reduce((sum, val) => sum + val, 0) / filteredValues.length;
}
