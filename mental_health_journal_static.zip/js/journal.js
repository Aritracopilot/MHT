// Journal-specific functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize journal entry events
    initializeJournalEvents();
    
    // Load journal entries if on journal page
    if (document.getElementById('journal-page').classList.contains('active')) {
        loadJournalEntries();
    }
});

// Initialize Journal Events
function initializeJournalEvents() {
    // Journal search functionality
    const journalSearch = document.getElementById('journalSearch');
    const clearSearch = document.getElementById('clearSearch');
    
    if (journalSearch) {
        journalSearch.addEventListener('input', function() {
            filterJournalEntries(this.value);
        });
    }
    
    if (clearSearch) {
        clearSearch.addEventListener('click', function() {
            journalSearch.value = '';
            filterJournalEntries('');
        });
    }
    
    // Save journal entry button
    const saveJournalEntry = document.getElementById('saveJournalEntry');
    if (saveJournalEntry) {
        saveJournalEntry.addEventListener('click', function() {
            const form = document.getElementById('journalEntryForm');
            if (form.checkValidity()) {
                window.app.saveJournalEntry();
            } else {
                form.reportValidity();
            }
        });
    }
    
    // Create first entry button
    const createFirstEntry = document.getElementById('createFirstEntry');
    if (createFirstEntry) {
        createFirstEntry.addEventListener('click', function() {
            window.app.openJournalEntryModal();
        });
    }
}

// Load Journal Entries
function loadJournalEntries() {
    const journalEntriesContainer = document.getElementById('journalEntries');
    if (!journalEntriesContainer) return;
    
    // Show loading state
    journalEntriesContainer.innerHTML = `
        <div class="text-center p-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading journal entries...</p>
        </div>
    `;
    
    // Get all journals
    const journals = JournalStorage.getAllJournals();
    
    // Update journal entries list
    updateJournalEntriesList(journals);
    
    // Load tag filters
    loadTagFilters();
}

// Update Journal Entries List
function updateJournalEntriesList(entries) {
    const journalEntriesContainer = document.getElementById('journalEntries');
    if (!journalEntriesContainer) return;
    
    if (entries.length === 0) {
        journalEntriesContainer.innerHTML = `
            <div class="placeholder-message">
                <i class="bi bi-journal-text"></i>
                <p>No journal entries yet</p>
                <button class="btn btn-primary" id="createFirstEntry">Create Your First Entry</button>
            </div>
        `;
        
        // Add event listener to create first entry button
        const createFirstEntry = document.getElementById('createFirstEntry');
        if (createFirstEntry) {
            createFirstEntry.addEventListener('click', function() {
                window.app.openJournalEntryModal();
            });
        }
        
        return;
    }
    
    let html = '';
    entries.forEach(entry => {
        // Get tag objects for this entry
        const entryTags = entry.tags.map(tagId => {
            return TagStorage.getTagById(tagId);
        }).filter(tag => tag !== null);
        
        // Get mood data if available
        let moodHtml = '';
        if (entry.mood_entries && entry.mood_entries.length > 0) {
            const mood = entry.mood_entries[0];
            moodHtml = `
                <div class="journal-entry-mood">
                    <span>Mood: ${mood.mood_score}/10</span>
                    <span>Energy: ${mood.energy_level}/10</span>
                </div>
            `;
        }
        
        // Create entry HTML
        html += `
            <div class="journal-entry" data-id="${entry.id}">
                <div class="journal-entry-header">
                    <h3 class="journal-entry-title">${entry.title}</h3>
                    <span class="journal-entry-date">${formatDate(entry.created_at)}</span>
                </div>
                <div class="journal-entry-tags">
                    ${entryTags.map(tag => `
                        <span class="tag" style="background-color: ${tag.color}" data-tag-id="${tag.id}">${tag.name}</span>
                    `).join('')}
                </div>
                <div class="journal-entry-content">
                    ${entry.content.substring(0, 200)}${entry.content.length > 200 ? '...' : ''}
                </div>
                ${moodHtml}
            </div>
        `;
    });
    
    journalEntriesContainer.innerHTML = html;
    
    // Add click event to view entry
    const journalEntryElements = journalEntriesContainer.querySelectorAll('.journal-entry');
    journalEntryElements.forEach(element => {
        element.addEventListener('click', function() {
            const entryId = this.getAttribute('data-id');
            window.app.viewJournalEntry(entryId);
        });
    });
}

// Update Journal Entries For Week
function updateJournalEntriesForWeek(entries) {
    // This function is called from app.js when week selector changes
    const journalPage = document.getElementById('journal-page');
    
    // Only update if on journal page
    if (journalPage && journalPage.classList.contains('active')) {
        updateJournalEntriesList(entries);
    }
}

// Filter Journal Entries
function filterJournalEntries(searchText) {
    const journalEntries = document.querySelectorAll('.journal-entry');
    
    journalEntries.forEach(entry => {
        const title = entry.querySelector('.journal-entry-title').textContent.toLowerCase();
        const content = entry.querySelector('.journal-entry-content').textContent.toLowerCase();
        const tags = Array.from(entry.querySelectorAll('.tag')).map(tag => tag.textContent.toLowerCase());
        
        const searchLower = searchText.toLowerCase();
        
        if (title.includes(searchLower) || content.includes(searchLower) || tags.some(tag => tag.includes(searchLower))) {
            entry.style.display = '';
        } else {
            entry.style.display = 'none';
        }
    });
}

// Load Tag Filters
function loadTagFilters() {
    const tagFiltersContainer = document.getElementById('tagFilters');
    if (!tagFiltersContainer) return;
    
    // Get all tags
    const tags = TagStorage.getAllTags();
    
    if (tags.length === 0) {
        tagFiltersContainer.innerHTML = '<span class="text-muted">No tags available</span>';
        return;
    }
    
    let html = '';
    tags.forEach(tag => {
        html += `
            <span class="tag filter-tag" data-id="${tag.id}" style="background-color: ${tag.color}">
                ${tag.name}
            </span>
        `;
    });
    
    tagFiltersContainer.innerHTML = html;
    
    // Add click event to filter by tag
    const filterTags = tagFiltersContainer.querySelectorAll('.filter-tag');
    filterTags.forEach(tag => {
        tag.addEventListener('click', function() {
            this.classList.toggle('active');
            filterJournalsByTags();
        });
    });
}

// Filter Journals by Tags
function filterJournalsByTags() {
    const selectedTags = Array.from(document.querySelectorAll('#tagFilters .filter-tag.active')).map(tag => tag.getAttribute('data-id'));
    const journalEntries = document.querySelectorAll('.journal-entry');
    
    if (selectedTags.length === 0) {
        // Show all entries if no tags selected
        journalEntries.forEach(entry => {
            entry.style.display = '';
        });
        return;
    }
    
    journalEntries.forEach(entry => {
        const entryTags = Array.from(entry.querySelectorAll('.tag')).map(tag => {
            return tag.getAttribute('data-tag-id');
        });
        
        // Check if entry has any of the selected tags
        const hasSelectedTag = selectedTags.some(tagId => entryTags.includes(tagId));
        
        if (hasSelectedTag) {
            entry.style.display = '';
        } else {
            entry.style.display = 'none';
        }
    });
}

// Helper Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}
