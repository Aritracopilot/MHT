# Mental Health Journal - Static Web App

This is a static web application for weekly mental health journaling with tags and mood charts. The application uses browser localStorage for data persistence, allowing users to track their mental health, organize journal entries with tags, and visualize mood trends over time.

## Features

- **Weekly Journal Entries**: Create and manage journal entries organized by week
- **Tagging System**: Categorize entries with customizable, color-coded tags
- **Mood Tracking**: Record mood and energy levels with each entry
- **Visual Analytics**: View mood trends and patterns through interactive charts
- **Responsive Design**: Works seamlessly on desktop and mobile devices
- **Data Export/Import**: Backup and restore your journal data

## Technical Details

This application is built with:

- **HTML5, CSS3, and JavaScript**: Pure frontend implementation
- **Bootstrap 5**: For responsive design and UI components
- **Chart.js**: For interactive mood and tag usage charts
- **localStorage API**: For client-side data persistence

## Deployment

This is a static web application that can be deployed to any static hosting service:

1. **Vercel**: Upload the entire directory or connect to a GitHub repository
2. **Netlify**: Upload the directory or use the Netlify CLI
3. **GitHub Pages**: Push to a GitHub repository and enable GitHub Pages

## Privacy Note

All data is stored locally in your browser's localStorage. No data is sent to any server. This means:

- Your data stays on your device
- You can export your data for backup
- Clearing browser data will erase your journal entries
- Your data is not accessible across different devices unless you manually import/export

## Browser Compatibility

This application works best in modern browsers that support localStorage and ES6 features:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
